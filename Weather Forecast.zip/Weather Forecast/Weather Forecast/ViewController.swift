//
//  ViewController.swift
//  Weather Forecast
//
//  Created by RENUKA BHRAMANNA on 18/01/23.
//

import UIKit
import CoreLocation

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    @IBOutlet weak var cityNameLabel: UILabel!
    @IBOutlet weak var currentTempLabel: UILabel!
    @IBOutlet weak var weatherTableView: UITableView!
    var locationData : City?
    var latitude = 0.0
    var longitude = 0.0
    let locationManager = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        getCurrentLocation()
        //  getData()
        
    }
    
    
    //// Get vurrent loction...
    
    func getCurrentLocation() {
        // Ask for Authorisation from the User.
        self.locationManager.requestAlwaysAuthorization()
        
        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
    }
    
    
    //// fetch data after location get...
    
    func getData() {
        let session = URLSession.shared
        //let lat = "18.6701"
        //let long = "73.7154"
        let apikey = "4b166a3991dd14419dcead1c9a1a4914"
        // let url = "http://openweathermap.org/forecast5?lat=\(lat)&lon=\(long)&appid=\(apikey)"
        
        //api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&appid={API key}
        
        let serviceUrl = URL(string:"http://api.openweathermap.org/data/2.5/forecast?lat=\(latitude)&lon=\(longitude)&appid=\(apikey)")
        
        print(serviceUrl!)
        
        let task = session.dataTask(with:serviceUrl!) { (serviceData, serviceResponse, error) in
            
            if error == nil{
                let httpResponse = serviceResponse as! HTTPURLResponse
                if(httpResponse.statusCode == 200){
                    // data parse
                    
                    guard let resultData = serviceData else {
                        return
                    }
                    
                    if let decodedResponse = try? JSONDecoder().decode(City.self, from: resultData) {
                        print("Data output \(decodedResponse)")
                        
                        self.locationData = decodedResponse
                        
                        DispatchQueue.main.async {
                            self.cityNameLabel.text=self.locationData?.city.name
                            
                            self.weatherTableView.reloadData()
                            
                        }
                        
                        
                    }
                    
                   
                }
                
            }
        }
        task.resume()
        
    }
    
    
    
    /// table view delegate methods...
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // 1
        return locationData?.list.count ?? 0
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = weatherTableView.dequeueReusableCell(withIdentifier: "cellweather", for: indexPath) as! WeatherCell
        cell.backgroundColor = UIColor.clear
        
        if let date = locationData?.list{
            cell.dateLabel.text = date[indexPath.row].dtTxt // "Day \(indexPath.row+1)"
            
            
            
            
         
                cell.mimaxLabel.text = "\(String(format: "%.0f", date[indexPath.row].main.tempMin - 273.15) + "°")  / \(String(format: "%.0f", date[indexPath.row].main.tempMax - 273.15) + "°")"
        
            
            cell.descriptionLabel.text = date[indexPath.row].weather[0].description.rawValue
        }
       
        
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 117.0;//Choose your custom row height
    }
}



///  Location manager delgate method...
extension ViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        latitude = locValue.latitude
        longitude = locValue.longitude
        
        print("locations afer getting  = \(latitude) \(longitude)")
        getData()
        
        
    }
}

